# redesign-the-wee-apes
redesign-the-wee-apes created by GitHub Classroom

# Setup
```
npm install

npm run start
```
